# Diversity-pilot disclosure report — Anthropic pair (v001)

Runbook: `diversity_runbook_anthropic_v001.md` (SHA-256 `cd2b5fee91f6496cdb639a4c2ca0d0da25c127ac4219d75bf05df6d1d2e00a7c`), researcher-approved by handoff prompt. Stage `diversity_pilot`, budget plan v004 (`9962c20d…d0988`). Report written 2026-08-16 (UTC).

## 1. Completion condition — MET

Both run directories show all scheduled slots terminal with zero invalid and zero pending across both arms; each run's `rating_records.jsonl` is merged with a reconciled `merge_receipt.json`; `analysis_v001.json` exists for each run (objective via `analyze_normalized_v001.py`; interpretive via the launcher's gated `analyze`).

## 2. Final status output, both runs

**Run A — `diversity_objective_anthropic_v001`** (255 items, 2 reps/route, 10 blocks, seed 20260812)

- Sub-agent arm (`unit_fanout.py status`): expected 510, terminal 510, invalid 0, pending 0, seal **verified**, superseded 0; terminal statuses: succeeded 510.
- API arm: expected 510, terminal 510 — succeeded 504, parse_failure 6.
- Both arms: **1,020 / 1,020 terminal, 0 invalid, 0 pending.** No stopfiles.

**Run B — `diversity_interpretive_anthropic_v001`** (45 items, 12 reps/route, 8 blocks, seed 20260813)

- Sub-agent arm: expected 540, terminal 540, invalid 0, pending 0, seal **verified**, superseded 1 (the single sanctioned linked retry); return-level statuses: succeeded 540.
- API arm: expected 540, terminal 540 — succeeded 508, parse_failure 31, transport_error 1.
- Both arms: **1,080 / 1,080 terminal, 0 invalid, 0 pending.** No stopfiles.

At collection, 2 of Run B's 540 valid sub-agent returns carried codings that failed the item response schema and were typed `parse_failure` in the rating records (worker returns valid; coded payloads schema-invalid).

## 3. Merge reconciliation

| Run | Merged | reconciled | By route/status | Output sha256 | Receipt sha256 |
|---|---|---|---|---|---|
| A objective | 1,020 | true | api: 504 succeeded / 6 parse_failure; subagent: 510 succeeded | `23bfba16de980098933e0dab46eafa414759c25d53081b7ae15b0fd725953562` | `3d84a17ce0515da4e27ab3dfe2af369703c5b5a4fbf422249afe5ec40c786bf7` |
| B interpretive | 1,080 | true | api: 508 succeeded / 31 parse_failure / 1 transport_error; subagent: 538 succeeded / 2 parse_failure | `0ec8017725657b5002eacf79741995b7fb16deb1eb7742306470110605b22a08` | `53bfea5a0b914f24516124a9154676092d3915d5c00018cee19f6cee598beeb1` |

Each analysis file's `merge_receipt_sha256` matches its run's receipt hash exactly.

## 4. Analysis artifacts

- Objective (MUST use normalized tool — done): `runs/diversity_objective_anthropic_v001/analysis_v001.json`, produced by `analyze_normalized_v001.py` (sha `be1acaa5…8896`, matching the pinned artifact). 1,020 records analyzed, 255/255 items scored, bootstrap B=2000 with BCa CIs. 168 free-text ratings across 42 items canonicalized.
- Interpretive (launcher's gated analyze — done): `runs/diversity_interpretive_anthropic_v001/analysis_v001.json`. 1,080 records analyzed, 45/45 items scored.
- Top-level `d_overall_weighted` / `shift_overall_weighted` print as null in both summaries because all items are `benchmark_phase: development_only`; full results are nested under `phases.development_only` (per-family AA/AS/SS, d, shift, validity blocks). This is a reporting-layer artifact, not missing analysis.
- The launcher's `analyze` was **not** run on the objective run at any point.

**Objective analysis `normalization` block hashes:**

| Field | SHA-256 |
|---|---|
| normalize_module (normalize_ratings_v001.py) | `175690050435eca900bd4b8acad9f81f4fa7c2d0403a37f2d38d876cdbfa660f` |
| normalizer_module (answer_equivalence_v001.py) | `d3e60cae51b498d05b55b878f013f4629c36d02f473bc68db01e7e25644a4567` |
| normalized_items (items_normalized.jsonl) | `c549add8852f633c87774f3743181f9d2d662c7399c5ba3089548aa8c7b48601` |
| normalized_ratings (rating_records_normalized.jsonl) | `7b591c77d99376205d1d28101a77b43a8b9520450d5df4f56424e366b7e40ca2` |
| source_ratings (rating_records.jsonl) | `23bfba16de980098933e0dab46eafa414759c25d53081b7ae15b0fd725953562` |

Both module hashes equal the runbook-pinned artifact hashes verified at precondition time.

## 5. Cost against the $120 stage ceiling

| | Archived attempts | Realized USD |
|---|---|---|
| Run A API arm | 529 (all with usage) | **$13.7329** |
| Run B API arm | 616 (613 with usage; 3 transport-failed attempts carry no usage) | **$22.7631** |
| **Stage total (API)** | 1,145 | **$36.4960 of $120.00 (30.4%)** |

Sub-agent route (subscription-metered, per budget plan tracked by attempts/wall-clock): 1,051 worker attempts (510 + 541); ≈60.46M sub-agent tokens across 19 block workflows (Run A ≈29.82M / 530 agents; Run B ≈30.58M / 559 agents incl. the retry dispatch); plus 57,294 tokens across three 529-overload discovery launches that dispatched zero workers. Fan-out wall-clock 23–65 min per block.

**Enforcement gap (disclosed):** the launcher enforces the $120 ceiling per run directory; Run B's projection never included Run A's realized spend. Combined spend stayed far under the ceiling, but the stage ceiling was not mechanically enforced jointly. Flagged for kit v0.5.

## 6. Retries (per arm, per run) — policy: one linked retry max, verified

Maximum archived attempts per slot is exactly 2 in both runs; no slot anywhere reached attempt 3.

| Run / arm | Slots retried | Retry outcomes (final status of retried slots) |
|---|---|---|
| A API | 19 of 510 | 13 succeeded on attempt 2; 6 parse_failure |
| A sub-agent | 0 of 510 | — |
| B API | 76 of 540 | 44 succeeded on attempt 2; 31 parse_failure; 1 transport_error |
| B sub-agent | 1 of 540 (`anthropic-div_interp_familiar_011-subagent-r08`) | attempt-1 return invalid (`worker_error`: worker detected its scratchpad helper scripts modified between write and execution, failed safe); single sanctioned `unit_fanout.py retry` → attempt 2 succeeded. Attempt-1 return archived; supersession recorded. |

Workflow-level relaunches (not slot retries): Run B block 2's discovery agent failed twice on `529 Overloaded` (zero workers dispatched each time) before succeeding on the third launch after a stand-down.

## 7. Model and effort

- Every one of the 1,145 archived API responses reports `claude-opus-5` (`reported_model_verified: true`); `requested_effort: high` sealed in both configs and echoed per record. No model drift during generation; no drift stopfile.
- Sub-agent arm: `subagent_requested_model: opus`, effort `high` pinned in every workflow invocation; per the sealed config, `reported_model_verified` is false by design on this route (host does not expose the wire model). This is the known provenance limit of `workflow/shared/observation-fanout.md`.
- Session model: generation of all 2,100 slots ran while this session was Claude Opus 5 (runbook precondition 2, reported at start; reasoning-effort setting not introspectable, disclosed then). After generation and most of the closing sequence, the researcher switched the session to **Fable 5 (Max)** for wrap-up; work performed under Fable 5 was exclusively deterministic (Run B collect/merge/analyze completion, Option C re-parse, verification, this report) — zero model-generated observations were added, and no fan-out was invoked after the switch.

## 8. Findings a reader of the analyses should know

1. **Route-asymmetric schema failures.** Every parse_failure but one is the same violation: `$.rationale` exceeding the frozen schema's `maxLength: 500`. API arm: 6/510 (1.2%) in Run A, 31/540 (5.7%) in Run B. Sub-agent arm: 0 and 2. The asymmetry gives the routes different effective denominators for a non-random reason (verbose-rationale items), concentrated in the 12-rep interpretive run. No stop rule was breached (worst block: 7/67 = 10.4% < 25%).
2. **Option C recovery (researcher-approved amendment, AMENDMENT_004).** Deterministic re-parse of the archived raw responses of all 37 parse_failure API records, validated with the launcher's own validator against the frozen schema relaxed only by removing `properties.rationale.maxLength`: **36/37 recovered** (Run A 6/6; Run B 30/31), full rationales retained, zero new model calls. The one non-recoverable record (`div_interp_novel_006-api-r11`) contained no valid JSON object at all. The transport_error slot is out of scope (nothing to re-parse). The 2 sub-agent-side parse_failures were **not** recovered (the approved rule covered API records only). Recovered datasets are supplementary: the preregistered primary analyses above are computed on the unrecovered records; the variant agreement analysis on recovered data is routed to Stage 14 under the amendment.
3. **The 8 Clark County restricted items** (Run A) were transmitted under the researcher's 2026-08-04 authorization (`hosted_transmission`, both routes). Their `material_ids` were independently verified inside `covered_material_ids` (the launcher's gate checks `source_id`/`covered_routes` only). Their `human_review_status` remains `pending_researcher`.
4. **Interpretive panel:** 0 restricted items (all public/synthetic).

## 9. Amendments (all in `runs/diversity_interpretive_anthropic_v001/amendments/`, originals preserved; AMENDMENT_004 also in Run A's `amendments/`)

| ID | What | Why | Authorization |
|---|---|---|---|
| AMENDMENT_001 | Parent `run_manifest.json` sealed hash for `subagent_run/run_manifest.json` updated `e53ff9f1…` → `0c025dae…`; parent `seal.json` recomputed | Sanctioned retry legitimately mutated the child manifest (entry swapped for attempt-2 successor; 540 rows, 0 duplicates, lineage recorded); parent seal was stale, collect failed closed | Researcher selected "re-seal, documented as amendment" |
| AMENDMENT_002 | `run_route_comparison.py` patched: `collect-subagent` falls back to `unit_id` lookup when `assignment_id` misses (sha `f8fe9be0…` → `b7ae3c62…`) | Retry renames `assignment_id` to `…-attempt002`; collect indexed only by `assignment_id` → "no assignment for slot". Fallback verified inert for Run A (0 renamed rows) | Researcher: "Please patch the launcher, I approve." |
| AMENDMENT_003 | Interpretive run's sealed `driver` hash updated to the patched launcher; parent seal recomputed | The run seals the driver source; the approved patch drifted it; collect failed closed | Mechanical completion of AMENDMENT_002, disclosed as higher-significance: Run A artifacts were produced by driver `f8fe9be0…`, Run B collect/merge/analyze by `b7ae3c62…` (delta = the inert fallback only) |
| AMENDMENT_004 | Option C maxLength recovery (both runs): characterization + recovered-records JSONL | See finding 2 | Researcher: "Let's do C for now…" |

## 10. Deviations and incidents (beyond the amendments)

1. **Concurrent-writer incident (operator error, Run A block 0):** a second `run-api --block 0` was launched while the first was alive (process liveness misread). Verified by slot-file mapping and monotonic timestamps: no double dispatch, no overwrite; 37 clean records; both processes killed, block resumed via the launcher's documented resume path. The same misread caused block 0 to be reported "51/51 succeeded" mid-run; corrected to 50/1 (final tallies in this report are from the run directories, not mid-run messages).
2. **`/elr-code-observations` wrapper skill was not separately invoked**; the saved workflow `.claude/workflows/elr-observation-fanout.js` was invoked directly with the runbook's exact arguments, and `workflow/shared/observation-fanout.md` was read and followed. Functional compliance; procedural note.
3. **Closing-sequence ordering:** the objective analysis ran before Run B's collect/merge (which were blocked by the seal defect). The runbook's binding constraint — no analysis, merge, or label inspection until both runs' generation was complete — was satisfied: both runs were fully terminal before any closing step. Blinding held throughout generation (operational counts only).
4. **529-overload stand-down** (three failed discovery launches, zero workers, ~5-min backoff) — reported to researcher at the time.
5. **Infrastructure (Google Drive File Stream):** two transient `EINVAL` read faults aborted `run-api` mid-block (files intact on re-read; integrity sweeps of all records/archives passed, 0 unparseable); once the entire `benchmarks/` tree vanished from the mount and was restored by the researcher — all 9 pinned artifact hashes re-verified matching post-restore, run contents reconciled exactly (the apparent count delta was block 3's pre-crash partial dispatch, all preserved). An orphaned collect process from a killed session completed 19 subagent_records writes; the rerun validated all 540 files rather than rewriting (written 0), and merge re-validated every record.
6. **Session-model switch to Fable 5 for wrap-up** — see §7.
7. Runbook precondition 2's effort claim is reported, not introspectively verifiable; the mechanically sealed `--effort high` is verified in both configs and all records.

## 11. Kit defects surfaced (recommend fixing in v0.5; this validation run caught them)

1. `unit_fanout.py retry` ↔ `run_route_comparison.py collect-subagent` incompatibility, two layers: (a) retry re-seals the child manifest but cannot update the parent's `sealed_files.subagent_run_manifest`; (b) collect resolves slots by `assignment_id` only, which retry renames. Any run needing a single retry becomes un-collectable without amendment. Fix: adopt the AMENDMENT_002 fallback (or read the manifest's `superseded` map) and have retry update the parent seal.
2. Stage budget ceiling enforced per run directory, not jointly across a stage's runs.
3. `rationale` `maxLength: 500` produces route-asymmetric typed failures and, per the researcher, should be dropped from the instrument (v0.5 revision-queue item; do not retrofit into v0.4).
4. Shared-scratchpad worker collision (one worker observed its helper scripts modified pre-execution and failed safe) — isolation limit worth noting in `observation-fanout.md`.
5. Analysis summary line prints null overall stats for single-phase (development_only) panels although full results exist under `phases`.

## 12. Complete list of files created or modified

**Modified outside the two run directories (sole item; researcher-approved AMENDMENT_002):**
- `benchmarks/intercoder-route-agreement/run_route_comparison.py` (sha `f8fe9be0b434fbe98a38e0649f180da1fe0bb3a441bb0913d629ca475acef3bf` → `b7ae3c626ec0ebd8df86ee156ee0b74b63f043dc3b160a15afa33d3b8196744c`; pre-patch copy preserved in Run B `amendments/`)

Nothing else outside the run directories was created or modified: no kit skill, workflow, schema, panel, envelope, budget, `project/` state, or documentation file was touched. Session-temporary working files (status snapshots, this report's draft, the recovery script) live in the session scratchpad outside the repository.

**Created — `benchmarks/intercoder-route-agreement/runs/diversity_objective_anthropic_v001/`:**
- Prepare (sealed): `config.json`, `approvals.json`, `schedule.jsonl`, `run_manifest.json`, `seal.json`, `subagent_fanout_spec.json`, `subagent_result_schema.json`
- Generation: `api_records/` (510), `api_archive/` (529), `subagent_run/` (`run_manifest.json`, `run_seal.json`, `unit_ledger.jsonl`, `assignments/` 510, `worker_returns/` 510)
- Closing: `subagent_records/` (510), `rating_records.jsonl` (1,020), `merge_receipt.json`, `analysis_v001.json`, `rating_records_normalized.jsonl`, `items_normalized.jsonl`
- Amendment: `amendments/AMENDMENT_004_option_c_maxlength_recovery.json`, `amendments/maxlength_recovered_records_v001.jsonl` (6 records)
- This report: `diversity_pilot_anthropic_disclosure_v001.md`

**Created — `…/runs/diversity_interpretive_anthropic_v001/`:**
- Prepare (sealed): same seven files as above
- Generation: `api_records/` (540), `api_archive/` (616), `subagent_run/` (`run_manifest.json`†, `run_seal.json`†, `unit_ledger.jsonl`, `assignments/` 541 incl. `…-attempt002`, `worker_returns/` 540 + `archive/` 1)  († modified by the sanctioned retry, which re-sealed the child)
- Closing: `subagent_records/` (540), `rating_records.jsonl` (1,080), `merge_receipt.json`, `analysis_v001.json`
- Modified by amendments: `run_manifest.json`, `seal.json` (AMENDMENT_001 and _003)
- `amendments/`: `AMENDMENT_001_subagent_manifest_reseal.json`, `pre_amendment_run_manifest.json`, `pre_amendment_seal.json`, `AMENDMENT_002_collect_subagent_unit_id_fallback.json`, `pre_amendment002_run_route_comparison.py`, `AMENDMENT_003_driver_reseal.json`, `pre_amendment003_run_manifest.json`, `pre_amendment003_seal.json`, `AMENDMENT_004_option_c_maxlength_recovery.json`, `maxlength_recovered_records_v001.jsonl` (30 records)
- This report: `diversity_pilot_anthropic_disclosure_v001.md`

No approved artifact, raw prompt, raw model response, validation record, or prior correction was overwritten at any point; every superseded item was archived, and all nine runbook-pinned artifact hashes still verify except the deliberately amended launcher, whose before/after hashes and preserved original are recorded above.

## 13. Compliance review (runbook, start to finish)

Preconditions 1–6 verified before any model call (all 9 artifact hashes matched; doctor green; key present, never printed). Run A prepared with the exact runbook command; 1,020 slots / 10 blocks / effort high confirmed. Blocks 0–9 executed strictly in order, API arm then sub-agent arm then serial validation within each block, block N+1 opened only after block N validated. Run B prepared only after Run A reconciled 1,020/0/0; 1,080 slots / 8 blocks confirmed; blocks 0–7 same discipline. No items or repeats added; retry policy never exceeded attempt 2; still-failing slots remain typed failures in the denominator. Blinding maintained until both runs' generation completed. Closing sequence commands run as written (collect→merge per run; objective analyzed only by `analyze_normalized_v001.py`; interpretive only by launcher `analyze`). Stop rules monitored continuously: no stopfiles, no drift, no ceiling breach, no block over 25%. Deviations, incidents, and amendments: fully enumerated in §§9–10.
