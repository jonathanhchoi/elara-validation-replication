"""Run-local compatibility wrapper for one canonical unit_fanout retry.

The frozen schedule addresses sub-agent work by the original unit/slot ID, while
unit_fanout's active manifest addresses a retried assignment by its attempt-specific
assignment ID.  The launcher collector indexes only by assignment ID.  This wrapper
adds the original unit ID as an in-memory alias for the one active retry, invokes the
unchanged launcher collector, and verifies that the sealed manifests did not change.
"""

from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path
from typing import Any


RUN_DIR = Path(__file__).resolve().parent
DRIVER_PATH = RUN_DIR.parent.parent / "run_route_comparison.py"
FANOUT_MANIFEST_PATH = (RUN_DIR / "subagent_run" / "run_manifest.json").resolve()
OUTER_MANIFEST_PATH = (RUN_DIR / "run_manifest.json").resolve()
RECEIPT_PATH = RUN_DIR / "collect_subagent_retry_compat_receipt_v001.json"
EXPECTED_UNIT_ID = "openai-div_contract_024-subagent-r02"
EXPECTED_RETRY_ID = f"{EXPECTED_UNIT_ID}-attempt002"


def _load_launcher() -> Any:
    spec = importlib.util.spec_from_file_location(
        "diversity_objective_launcher_retry_compat_v001", DRIVER_PATH
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load launcher from {DRIVER_PATH}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    if RECEIPT_PATH.exists():
        raise RuntimeError(f"refusing to overwrite compatibility receipt: {RECEIPT_PATH}")

    launcher = _load_launcher()
    outer_hash_before = launcher.sha256_file(OUTER_MANIFEST_PATH)
    fanout_hash_before = launcher.sha256_file(FANOUT_MANIFEST_PATH)
    source_hash = launcher.sha256_file(Path(__file__).resolve())

    real_load_json = launcher.load_json
    fanout_manifest = real_load_json(FANOUT_MANIFEST_PATH)
    assignments = fanout_manifest.get("assignments")
    if not isinstance(assignments, list):
        raise RuntimeError("fanout manifest has no assignments list")

    retries = [
        row
        for row in assignments
        if row.get("assignment_id") != row.get("unit_id")
    ]
    if len(retries) != 1:
        raise RuntimeError(f"expected exactly one active retry, found {len(retries)}")
    retry = retries[0]
    if retry.get("unit_id") != EXPECTED_UNIT_ID:
        raise RuntimeError(f"unexpected retry unit_id: {retry.get('unit_id')!r}")
    if retry.get("assignment_id") != EXPECTED_RETRY_ID or retry.get("attempt") != 2:
        raise RuntimeError(
            "unexpected active retry identity: "
            f"assignment_id={retry.get('assignment_id')!r}, attempt={retry.get('attempt')!r}"
        )
    if any(row.get("assignment_id") == EXPECTED_UNIT_ID for row in assignments):
        raise RuntimeError("original assignment ID is already active; alias is unnecessary")

    assignment_path = Path(retry["assignment_path"])
    return_path = Path(retry["return_path"])
    if not assignment_path.is_file() or not return_path.is_file():
        raise RuntimeError("active retry assignment or return is missing")
    if launcher.sha256_file(assignment_path) != retry.get("assignment_sha256"):
        raise RuntimeError("active retry assignment hash mismatch")

    projection = copy.deepcopy(fanout_manifest)
    alias = copy.deepcopy(retry)
    alias["assignment_id"] = EXPECTED_UNIT_ID
    projection["assignments"].append(alias)
    projected_loads = 0

    def compat_load_json(path: Path) -> Any:
        nonlocal projected_loads
        candidate = Path(path).resolve()
        if candidate == FANOUT_MANIFEST_PATH:
            projected_loads += 1
            return copy.deepcopy(projection)
        return real_load_json(path)

    launcher.load_json = compat_load_json
    try:
        result = launcher.collect_subagent(RUN_DIR)
    finally:
        launcher.load_json = real_load_json

    if projected_loads != 1:
        raise RuntimeError(
            f"expected one in-memory manifest projection, observed {projected_loads}"
        )
    if sum(result.get("terminal_status_counts", {}).values()) != 510:
        raise RuntimeError(f"collector did not reconcile 510 slots: {result!r}")
    record_count = len(list((RUN_DIR / "subagent_records").glob("*.json")))
    if record_count != 510:
        raise RuntimeError(f"expected 510 sub-agent records, found {record_count}")

    outer_hash_after = launcher.sha256_file(OUTER_MANIFEST_PATH)
    fanout_hash_after = launcher.sha256_file(FANOUT_MANIFEST_PATH)
    if outer_hash_after != outer_hash_before or fanout_hash_after != fanout_hash_before:
        raise RuntimeError("a sealed manifest changed during compatibility collection")

    receipt = {
        "compatibility_wrapper": "collect_subagent_retry_compat_v001",
        "reason": (
            "the launcher collector indexes active fanout rows by assignment_id, "
            "but the frozen schedule indexes the retried unit by its original slot_id"
        ),
        "scope": "in_memory_alias_only",
        "source_path": str(Path(__file__).resolve()),
        "source_sha256": source_hash,
        "original_unit_id": EXPECTED_UNIT_ID,
        "active_retry_assignment_id": EXPECTED_RETRY_ID,
        "active_retry_attempt": 2,
        "projected_manifest_loads": projected_loads,
        "collector_result": result,
        "subagent_record_count": record_count,
        "outer_manifest_sha256_before": outer_hash_before,
        "outer_manifest_sha256_after": outer_hash_after,
        "fanout_manifest_sha256_before": fanout_hash_before,
        "fanout_manifest_sha256_after": fanout_hash_after,
        "sealed_manifests_unchanged": True,
        "forbidden_artifacts_modified": False,
    }
    launcher.atomic_json(RECEIPT_PATH, receipt)
    print(json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
