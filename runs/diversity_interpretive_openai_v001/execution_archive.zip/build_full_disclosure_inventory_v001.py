"""Create a complete hashed inventory of both diversity OpenAI run directories."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


RUN_B = Path(__file__).resolve().parent
RUNS_ROOT = RUN_B.parent
REPO_ROOT = RUNS_ROOT.parent.parent.parent
RUN_DIRS = [
    RUNS_ROOT / "diversity_objective_openai_v001",
    RUNS_ROOT / "diversity_interpretive_openai_v001",
]
OUTPUT = RUN_B / "full_disclosure_file_inventory_v001.json"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    if OUTPUT.exists():
        raise RuntimeError(f"refusing to overwrite inventory: {OUTPUT}")
    entries = []
    for run_dir in RUN_DIRS:
        for path in sorted(p for p in run_dir.rglob("*") if p.is_file()):
            if path == OUTPUT:
                continue
            stat = path.stat()
            entries.append(
                {
                    "path": path.relative_to(REPO_ROOT).as_posix(),
                    "size_bytes": stat.st_size,
                    "sha256": sha256_file(path),
                }
            )
    entries.append(
        {
            "path": OUTPUT.relative_to(REPO_ROOT).as_posix(),
            "size_bytes": None,
            "sha256": None,
            "note": "self-referential inventory output; path included, hash intentionally omitted",
        }
    )
    payload = {
        "schema_version": "1.0",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scope": [str(path.resolve()) for path in RUN_DIRS],
        "entry_count": len(entries),
        "entries": sorted(entries, key=lambda row: row["path"]),
    }
    with OUTPUT.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({"output": str(OUTPUT), "entry_count": len(entries)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
